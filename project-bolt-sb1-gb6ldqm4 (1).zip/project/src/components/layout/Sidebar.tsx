import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, Wrench, Package, ClipboardList, 
  BarChart2, Bell, Settings, ChevronLeft, ChevronRight, 
  LogOut, Users, HardDrive, Activity 
} from 'lucide-react';

const Sidebar: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false);

  const toggleSidebar = () => {
    setCollapsed(!collapsed);
  };

  const navItems = [
    { name: 'Tableau de bord', path: '/', icon: <LayoutDashboard size={20} /> },
    { name: 'Interventions', path: '/interventions', icon: <Wrench size={20} /> },
    { name: 'Équipements', path: '/equipments', icon: <HardDrive size={20} /> },
    { name: 'Stock', path: '/inventory', icon: <Package size={20} /> },
    { name: 'Planning', path: '/planning', icon: <ClipboardList size={20} /> },
    { name: 'Prédictif', path: '/predictive', icon: <Activity size={20} /> },
    { name: 'Rapports', path: '/reports', icon: <BarChart2 size={20} /> },
    { name: 'Techniciens', path: '/technicians', icon: <Users size={20} /> },
  ];

  return (
    <div className={`h-screen bg-gray-900 text-white flex flex-col transition-all duration-300 ease-in-out ${collapsed ? 'w-16' : 'w-64'}`}>
      <div className="flex items-center justify-between p-4 border-b border-gray-800">
        {!collapsed && (
          <h1 className="text-xl font-bold">GMAO Pro</h1>
        )}
        <button
          onClick={toggleSidebar}
          className={`text-gray-400 hover:text-white transition-colors ${collapsed ? 'mx-auto' : ''}`}
        >
          {collapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
        </button>
      </div>

      <nav className="flex-1 overflow-y-auto py-4">
        <ul className="space-y-1">
          {navItems.map((item) => (
            <li key={item.path}>
              <NavLink
                to={item.path}
                className={({ isActive }) => `
                  flex items-center p-3 mx-2 rounded-lg
                  ${isActive ? 'bg-blue-700 text-white' : 'text-gray-300 hover:bg-gray-800'}
                  transition-colors duration-200
                `}
              >
                <span className="flex-shrink-0">{item.icon}</span>
                {!collapsed && <span className="ml-3">{item.name}</span>}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>

      <div className="p-4 border-t border-gray-800">
        <ul className="space-y-1">
          <li>
            <NavLink
              to="/notifications"
              className={({ isActive }) => `
                flex items-center p-3 rounded-lg
                ${isActive ? 'bg-blue-700 text-white' : 'text-gray-300 hover:bg-gray-800'}
                transition-colors duration-200
              `}
            >
              <Bell size={20} />
              {!collapsed && <span className="ml-3">Notifications</span>}
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/settings"
              className={({ isActive }) => `
                flex items-center p-3 rounded-lg
                ${isActive ? 'bg-blue-700 text-white' : 'text-gray-300 hover:bg-gray-800'}
                transition-colors duration-200
              `}
            >
              <Settings size={20} />
              {!collapsed && <span className="ml-3">Paramètres</span>}
            </NavLink>
          </li>
          <li>
            <button
              className="flex items-center p-3 rounded-lg w-full text-left
               text-gray-300 hover:bg-gray-800 transition-colors duration-200"
            >
              <LogOut size={20} />
              {!collapsed && <span className="ml-3">Déconnexion</span>}
            </button>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Sidebar;