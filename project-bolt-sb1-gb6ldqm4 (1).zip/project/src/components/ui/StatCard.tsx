import React from 'react';
import { ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  icon?: React.ReactNode;
  change?: {
    value: number;
    trend: 'up' | 'down' | 'neutral';
  };
  className?: string;
}

const StatCard: React.FC<StatCardProps> = ({ 
  title, 
  value, 
  icon, 
  change,
  className = '' 
}) => {
  const getTrendColor = (trend: 'up' | 'down' | 'neutral') => {
    switch (trend) {
      case 'up':
        return 'text-green-500';
      case 'down':
        return 'text-red-500';
      case 'neutral':
      default:
        return 'text-gray-500';
    }
  };

  const getTrendIcon = (trend: 'up' | 'down' | 'neutral') => {
    switch (trend) {
      case 'up':
        return <ArrowUpRight size={16} className="ml-1" />;
      case 'down':
        return <ArrowDownRight size={16} className="ml-1" />;
      case 'neutral':
      default:
        return <Minus size={16} className="ml-1" />;
    }
  };

  return (
    <div className={`bg-white rounded-lg border border-gray-200 p-5 shadow-sm ${className}`}>
      <div className="flex justify-between items-start">
        <p className="text-gray-500 text-sm font-medium">{title}</p>
        {icon && <div className="text-gray-400">{icon}</div>}
      </div>
      
      <div className="mt-3">
        <p className="text-2xl font-semibold text-gray-900">{value}</p>
        
        {change && (
          <div className={`flex items-center mt-2 ${getTrendColor(change.trend)}`}>
            <span className="text-sm font-medium">
              {change.value}%
            </span>
            {getTrendIcon(change.trend)}
          </div>
        )}
      </div>
    </div>
  );
};

export default StatCard;