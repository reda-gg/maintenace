import React from 'react';

interface StatusIndicatorProps {
  status: 'operational' | 'maintenance' | 'breakdown' | 'retired' | 
          'requested' | 'planned' | 'in_progress' | 'on_hold' | 'completed' | 'cancelled' |
          'low' | 'medium' | 'high' | 'critical';
  withLabel?: boolean;
  className?: string;
}

const StatusIndicator: React.FC<StatusIndicatorProps> = ({ 
  status, 
  withLabel = true,
  className = '' 
}) => {
  // Equipment status
  const equipmentStatusConfig = {
    operational: { color: 'bg-green-500', label: 'Opérationnel' },
    maintenance: { color: 'bg-amber-500', label: 'En maintenance' },
    breakdown: { color: 'bg-red-500', label: 'En panne' },
    retired: { color: 'bg-gray-500', label: 'Retiré' },
  };

  // Intervention status
  const interventionStatusConfig = {
    requested: { color: 'bg-purple-500', label: 'Demandée' },
    planned: { color: 'bg-blue-500', label: 'Planifiée' },
    in_progress: { color: 'bg-amber-500', label: 'En cours' },
    on_hold: { color: 'bg-orange-500', label: 'En attente' },
    completed: { color: 'bg-green-500', label: 'Terminée' },
    cancelled: { color: 'bg-gray-500', label: 'Annulée' },
  };

  // Priority status
  const priorityStatusConfig = {
    low: { color: 'bg-blue-500', label: 'Faible' },
    medium: { color: 'bg-amber-500', label: 'Moyenne' },
    high: { color: 'bg-orange-500', label: 'Haute' },
    critical: { color: 'bg-red-500', label: 'Critique' },
  };

  // Combine all status configs
  const statusConfig = {
    ...equipmentStatusConfig,
    ...interventionStatusConfig,
    ...priorityStatusConfig
  };

  const config = statusConfig[status] || { color: 'bg-gray-500', label: 'Inconnu' };

  return (
    <div className={`flex items-center ${className}`}>
      <div className={`h-2.5 w-2.5 rounded-full ${config.color} mr-2`}></div>
      {withLabel && <span className="text-sm">{config.label}</span>}
    </div>
  );
};

export default StatusIndicator;