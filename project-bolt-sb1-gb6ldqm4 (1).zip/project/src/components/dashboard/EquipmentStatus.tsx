import React from 'react';
import { HardDrive } from 'lucide-react';
import { Equipment } from '../../types';
import StatusIndicator from '../ui/StatusIndicator';
import { getRelativeTimeString } from '../../utils/dateUtils';

interface EquipmentStatusProps {
  equipment: Equipment[];
  className?: string;
}

const EquipmentStatus: React.FC<EquipmentStatusProps> = ({ 
  equipment,
  className = ''
}) => {
  const getEquipmentStats = () => {
    const stats = {
      total: equipment.length,
      operational: 0,
      maintenance: 0,
      breakdown: 0,
      retired: 0
    };
    
    equipment.forEach(item => {
      stats[item.status]++;
    });
    
    return stats;
  };
  
  const stats = getEquipmentStats();
  const criticalEquipment = equipment.filter(e => e.status === 'breakdown');

  return (
    <div className={`bg-white rounded-lg border border-gray-200 overflow-hidden ${className}`}>
      <div className="px-6 py-4 border-b border-gray-200">
        <h3 className="font-medium">État des équipements</h3>
      </div>
      
      <div className="p-6">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
          <div className="text-center">
            <div className="text-gray-500 text-sm">Total</div>
            <div className="text-2xl font-semibold">{stats.total}</div>
          </div>
          <div className="text-center">
            <div className="text-gray-500 text-sm">Opérationnels</div>
            <div className="text-2xl font-semibold text-green-600">{stats.operational}</div>
          </div>
          <div className="text-center">
            <div className="text-gray-500 text-sm">En maintenance</div>
            <div className="text-2xl font-semibold text-amber-500">{stats.maintenance}</div>
          </div>
          <div className="text-center">
            <div className="text-gray-500 text-sm">En panne</div>
            <div className="text-2xl font-semibold text-red-600">{stats.breakdown}</div>
          </div>
        </div>
        
        {criticalEquipment.length > 0 && (
          <div>
            <h4 className="font-medium text-gray-900 mb-3">Équipements en panne</h4>
            <ul className="divide-y divide-gray-200">
              {criticalEquipment.map(item => (
                <li key={item.id} className="py-3 flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <div className="w-8 h-8 rounded-lg bg-red-100 flex items-center justify-center text-red-600">
                      <HardDrive size={18} />
                    </div>
                  </div>
                  <div className="ml-3 flex-1">
                    <div className="flex items-center justify-between">
                      <h5 className="text-sm font-medium text-gray-900">{item.name}</h5>
                      <StatusIndicator status={item.status} />
                    </div>
                    <p className="mt-1 text-xs text-gray-500">{item.location}</p>
                    <p className="mt-1 text-xs text-gray-500">
                      Dernière maintenance: {item.lastMaintenance ? getRelativeTimeString(item.lastMaintenance) : 'N/A'}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
};

export default EquipmentStatus;