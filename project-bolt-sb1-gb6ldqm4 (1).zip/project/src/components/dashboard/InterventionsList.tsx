import React from 'react';
import { ChevronRight } from 'lucide-react';
import Badge from '../ui/Badge';
import { Intervention, Equipment, User } from '../../types';
import StatusIndicator from '../ui/StatusIndicator';
import { getRelativeTimeString } from '../../utils/dateUtils';

interface InterventionsListProps {
  interventions: Intervention[];
  equipment: Equipment[];
  users: User[];
  className?: string;
}

const InterventionsList: React.FC<InterventionsListProps> = ({ 
  interventions, 
  equipment,
  users,
  className = ''
}) => {
  return (
    <div className={`bg-white rounded-lg border border-gray-200 overflow-hidden ${className}`}>
      <div className="px-6 py-4 border-b border-gray-200">
        <h3 className="font-medium">Interventions à venir</h3>
      </div>
      
      <div className="overflow-hidden">
        {interventions.length === 0 ? (
          <div className="p-6 text-center text-gray-500">
            Aucune intervention à venir
          </div>
        ) : (
          <ul className="divide-y divide-gray-200">
            {interventions.map((intervention) => {
              const relatedEquipment = equipment.find(e => e.id === intervention.equipmentId);
              const assignee = intervention.assigneeId 
                ? users.find(u => u.id === intervention.assigneeId)
                : null;
                
              return (
                <li key={intervention.id} className="hover:bg-gray-50 transition-colors">
                  <div className="px-6 py-4">
                    <div className="flex justify-between items-center">
                      <p className="font-medium text-gray-900">{intervention.title}</p>
                      <StatusIndicator status={intervention.status} className="lg:block hidden" />
                    </div>
                    
                    <div className="mt-2 flex items-center text-sm text-gray-500">
                      <span className="block">
                        {relatedEquipment?.name} - {intervention.type === 'preventive' ? 'Préventif' : 
                          intervention.type === 'corrective' ? 'Correctif' : 'Réglementaire'}
                      </span>
                      <span className="mx-1.5">•</span>
                      <Badge variant={intervention.priority}>{
                        intervention.priority === 'low' ? 'Faible' :
                        intervention.priority === 'medium' ? 'Moyenne' :
                        intervention.priority === 'high' ? 'Haute' : 'Critique'
                      }</Badge>
                    </div>
                    
                    <div className="mt-2 flex items-center justify-between">
                      <div className="flex items-center text-sm text-gray-500">
                        {intervention.scheduledFor && (
                          <span>{getRelativeTimeString(intervention.scheduledFor)}</span>
                        )}
                        
                        {assignee && (
                          <>
                            <span className="mx-1.5">•</span>
                            <div className="flex items-center">
                              <img 
                                src={assignee.avatar} 
                                alt={assignee.name}
                                className="w-5 h-5 rounded-full mr-1.5"
                              />
                              <span>{assignee.name}</span>
                            </div>
                          </>
                        )}
                      </div>
                      
                      <button className="text-blue-600 hover:text-blue-800 transition-colors">
                        <ChevronRight size={18} />
                      </button>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
};

export default InterventionsList;