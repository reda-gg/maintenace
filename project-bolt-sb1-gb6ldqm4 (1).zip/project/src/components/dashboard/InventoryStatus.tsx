import React from 'react';
import { Package } from 'lucide-react';
import { Part } from '../../types';
import Button from '../ui/Button';

interface InventoryStatusProps {
  parts: Part[];
  className?: string;
}

const InventoryStatus: React.FC<InventoryStatusProps> = ({ 
  parts,
  className = ''
}) => {
  const lowStockParts = parts.filter(part => part.quantity <= part.minimumStock);
  
  return (
    <div className={`bg-white rounded-lg border border-gray-200 overflow-hidden ${className}`}>
      <div className="px-6 py-4 border-b border-gray-200">
        <h3 className="font-medium">Stock et approvisionnement</h3>
      </div>
      
      <div className="p-6">
        <div className="flex justify-between items-center mb-4">
          <h4 className="font-medium text-gray-900">Articles en alerte de stock</h4>
          <Button 
            variant="outline" 
            size="sm"
          >
            Gérer le stock
          </Button>
        </div>
        
        {lowStockParts.length === 0 ? (
          <div className="text-center text-gray-500 py-6">
            Aucun article en alerte de stock
          </div>
        ) : (
          <ul className="divide-y divide-gray-200">
            {lowStockParts.map(part => (
              <li key={part.id} className="py-3 flex items-start">
                <div className="flex-shrink-0 mt-1">
                  <div className="w-8 h-8 rounded-lg bg-amber-100 flex items-center justify-center text-amber-600">
                    <Package size={18} />
                  </div>
                </div>
                <div className="ml-3 flex-1">
                  <div className="flex items-center justify-between">
                    <h5 className="text-sm font-medium text-gray-900">{part.name}</h5>
                    <span className={`text-sm font-medium ${
                      part.quantity === 0 ? 'text-red-600' : 'text-amber-600'
                    }`}>
                      {part.quantity} / {part.minimumStock}
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-gray-500">Réf: {part.reference}</p>
                  <p className="mt-1 text-xs text-gray-500">
                    {part.location} • {part.supplier}
                  </p>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default InventoryStatus;