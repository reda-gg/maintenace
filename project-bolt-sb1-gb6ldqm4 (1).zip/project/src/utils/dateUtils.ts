import { format as dateFnsFormat, addDays as dateFnsAddDays, subDays as dateFnsSubDays } from 'date-fns';
import { fr } from 'date-fns/locale';

// Format a date with optional pattern and localization
export const format = (date: Date | string, pattern: string = 'dd/MM/yyyy'): string => {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  return dateFnsFormat(dateObj, pattern, { locale: fr });
};

// Add days to a date
export const addDays = (date: Date | string, days: number): string => {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  return dateFnsAddDays(dateObj, days).toISOString();
};

// Subtract days from a date
export const subDays = (date: Date | string, days: number): string => {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  return dateFnsSubDays(dateObj, days).toISOString();
};

// Get relative time string (e.g., "il y a 3 jours", "dans 5 jours")
export const getRelativeTimeString = (dateString: string): string => {
  const date = new Date(dateString);
  const now = new Date();
  const diffInMs = date.getTime() - now.getTime();
  const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));
  
  if (diffInDays === 0) {
    return "Aujourd'hui";
  } else if (diffInDays === 1) {
    return "Demain";
  } else if (diffInDays === -1) {
    return "Hier";
  } else if (diffInDays > 0) {
    return `Dans ${diffInDays} jours`;
  } else {
    return `Il y a ${Math.abs(diffInDays)} jours`;
  }
};

// Determine if a date is overdue (in the past)
export const isOverdue = (dateString?: string): boolean => {
  if (!dateString) return false;
  return new Date(dateString) < new Date();
};

// Get the appropriate status color based on date
export const getStatusColorByDate = (dateString?: string): string => {
  if (!dateString) return 'gray';
  
  const date = new Date(dateString);
  const now = new Date();
  const diffInDays = Math.floor((date.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  
  if (diffInDays < 0) return 'error';
  if (diffInDays <= 7) return 'warning';
  return 'success';
};