import { Equipment, Intervention, Part, User, Notification, KPI } from '../types';
import { addDays, subDays, format } from '../utils/dateUtils';

// Mock current date for consistent data
const NOW = new Date().toISOString();
const TODAY = format(new Date(), 'yyyy-MM-dd');

// Mock Users
export const mockUsers: User[] = [
  {
    id: 'u1',
    name: 'Jean Dupont',
    email: 'jean.dupont@example.com',
    role: 'admin',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 'u2', 
    name: 'Marie Lambert',
    email: 'marie.lambert@example.com',
    role: 'manager',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 'u3',
    name: 'Thomas Martin',
    email: 'thomas.martin@example.com',
    role: 'technician',
    avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 'u4',
    name: 'Sophie Petit',
    email: 'sophie.petit@example.com',
    role: 'technician',
    avatar: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 'u5',
    name: 'Lucas Bernard',
    email: 'lucas.bernard@example.com',
    role: 'requester',
    avatar: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  }
];

// Mock Equipment
export const mockEquipment: Equipment[] = [
  {
    id: 'e1',
    name: 'Climatiseur central',
    category: 'HVAC',
    location: 'Bâtiment A, 3ème étage',
    serialNumber: 'HVAC-2023-001',
    installDate: '2023-01-15',
    lastMaintenance: '2023-06-20',
    nextMaintenance: addDays(new Date(), 45),
    status: 'operational',
    manufacturer: 'ClimaTech',
    model: 'CT-5000',
    notes: 'Entretien régulier tous les 6 mois',
    image: 'https://images.pexels.com/photos/4078330/pexels-photo-4078330.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 'e2',
    name: 'Ascenseur principal',
    category: 'Vertical Transport',
    location: 'Bâtiment A, Hall',
    serialNumber: 'EL-2020-003',
    installDate: '2020-03-10',
    lastMaintenance: '2023-05-15',
    nextMaintenance: addDays(new Date(), 15),
    status: 'operational',
    manufacturer: 'ElevaPro',
    model: 'EP-2000',
    notes: 'Inspection réglementaire annuelle obligatoire',
    image: 'https://images.pexels.com/photos/6353673/pexels-photo-6353673.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 'e3',
    name: 'Groupe électrogène',
    category: 'Electrical',
    location: 'Bâtiment A, Sous-sol',
    serialNumber: 'GE-2021-007',
    installDate: '2021-08-12',
    lastMaintenance: '2023-04-10',
    nextMaintenance: addDays(new Date(), 80),
    status: 'maintenance',
    manufacturer: 'PowerGen',
    model: 'PG-10000',
    notes: 'Test mensuel de démarrage',
    image: 'https://images.pexels.com/photos/236748/pexels-photo-236748.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 'e4',
    name: 'Système de sécurité incendie',
    category: 'Safety',
    location: 'Tous bâtiments',
    serialNumber: 'SSI-2022-012',
    installDate: '2022-01-20',
    lastMaintenance: '2023-01-25',
    nextMaintenance: addDays(new Date(), 5),
    status: 'operational',
    manufacturer: 'FireSafe',
    model: 'FS-500',
    notes: 'Vérification obligatoire tous les 6 mois',
    image: 'https://images.pexels.com/photos/6440059/pexels-photo-6440059.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 'e5',
    name: 'Chaîne de production A',
    category: 'Production',
    location: 'Usine, Zone 2',
    serialNumber: 'PROD-2019-045',
    installDate: '2019-05-30',
    lastMaintenance: '2023-03-05',
    nextMaintenance: addDays(new Date(), 25),
    status: 'breakdown',
    manufacturer: 'IndusTech',
    model: 'IT-2000',
    notes: 'Maintenance hebdomadaire requise',
    image: 'https://images.pexels.com/photos/2547565/pexels-photo-2547565.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  }
];

// Mock Interventions
export const mockInterventions: Intervention[] = [
  {
    id: 'i1',
    title: 'Maintenance préventive climatisation',
    description: 'Maintenance semestrielle planifiée du système de climatisation central',
    equipmentId: 'e1',
    requesterId: 'u2',
    assigneeId: 'u3',
    priority: 'medium',
    status: 'planned',
    type: 'preventive',
    createdAt: subDays(new Date(), 15),
    scheduledFor: addDays(new Date(), 3),
    estimatedDuration: 180,
    notes: 'Prévoir remplacement des filtres'
  },
  {
    id: 'i2',
    title: 'Panne ascenseur principal',
    description: 'Ascenseur bloqué au 2ème étage, personnes évacuées',
    equipmentId: 'e2',
    requesterId: 'u5',
    assigneeId: 'u3',
    priority: 'critical',
    status: 'in_progress',
    type: 'corrective',
    createdAt: subDays(new Date(), 1),
    scheduledFor: TODAY,
    estimatedDuration: 240
  },
  {
    id: 'i3',
    title: 'Inspection réglementaire groupe électrogène',
    description: 'Vérification annuelle obligatoire conforme à la norme NF C 15-100',
    equipmentId: 'e3',
    requesterId: 'u2',
    assigneeId: 'u4',
    priority: 'high',
    status: 'planned',
    type: 'regulatory',
    createdAt: subDays(new Date(), 30),
    scheduledFor: addDays(new Date(), 10),
    estimatedDuration: 360,
    notes: 'Prévoir arrêt général de 2h pour tests'
  },
  {
    id: 'i4',
    title: 'Remplacement détecteurs incendie',
    description: 'Remplacement programmé des détecteurs du 1er étage',
    equipmentId: 'e4',
    requesterId: 'u2',
    assigneeId: 'u4',
    priority: 'medium',
    status: 'planned',
    type: 'preventive',
    createdAt: subDays(new Date(), 10),
    scheduledFor: addDays(new Date(), 4),
    estimatedDuration: 240
  },
  {
    id: 'i5',
    title: 'Réparation chaîne de production',
    description: 'Panne moteur principal sur chaîne de production A',
    equipmentId: 'e5',
    requesterId: 'u5',
    assigneeId: 'u3',
    priority: 'high',
    status: 'in_progress',
    type: 'corrective',
    createdAt: subDays(new Date(), 2),
    scheduledFor: TODAY,
    estimatedDuration: 480,
    notes: 'Arrêt complet de la production - Priorité absolue'
  },
  {
    id: 'i6',
    title: 'Maintenance système de sécurité',
    description: 'Vérification semestrielle des systèmes d\'alarme et contrôle d\'accès',
    equipmentId: 'e4',
    requesterId: 'u2',
    assigneeId: null,
    priority: 'low',
    status: 'requested',
    type: 'preventive',
    createdAt: subDays(new Date(), 5),
    scheduledFor: addDays(new Date(), 14),
    estimatedDuration: 180
  }
];

// Mock Parts
export const mockParts: Part[] = [
  {
    id: 'p1',
    name: 'Filtre climatisation standard',
    reference: 'FC-STD-2023',
    location: 'Magasin A, Étagère 3',
    quantity: 15,
    minimumStock: 5,
    unitPrice: 45.99,
    supplier: 'ClimaTech',
    category: 'Filtres',
    lastRestockDate: subDays(new Date(), 45),
    image: 'https://images.pexels.com/photos/257736/pexels-photo-257736.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 'p2',
    name: 'Moteur électrique 1.5kW',
    reference: 'ME-1.5-2023',
    location: 'Magasin B, Zone sécurisée',
    quantity: 2,
    minimumStock: 1,
    unitPrice: 789.99,
    supplier: 'ElectroPro',
    category: 'Moteurs',
    lastRestockDate: subDays(new Date(), 90),
    image: 'https://images.pexels.com/photos/2356087/pexels-photo-2356087.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 'p3',
    name: 'Détecteur de fumée',
    reference: 'DF-ION-2023',
    location: 'Magasin A, Étagère 7',
    quantity: 32,
    minimumStock: 10,
    unitPrice: 59.99,
    supplier: 'FireSafe',
    category: 'Sécurité',
    lastRestockDate: subDays(new Date(), 15),
    image: 'https://images.pexels.com/photos/5875855/pexels-photo-5875855.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 'p4',
    name: 'Courroie de transmission A47',
    reference: 'CT-A47-2023',
    location: 'Magasin B, Étagère 12',
    quantity: 3,
    minimumStock: 5,
    unitPrice: 129.99,
    supplier: 'TransTech',
    category: 'Transmission',
    lastRestockDate: subDays(new Date(), 120),
    image: 'https://images.pexels.com/photos/995751/pexels-photo-995751.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 'p5',
    name: 'Kit d\'entretien ascenseur',
    reference: 'KE-ASC-2023',
    location: 'Magasin A, Étagère 9',
    quantity: 4,
    minimumStock: 2,
    unitPrice: 349.99,
    supplier: 'ElevaPro',
    category: 'Kits',
    lastRestockDate: subDays(new Date(), 60),
    image: 'https://images.pexels.com/photos/8437956/pexels-photo-8437956.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  }
];

// Mock Notifications
export const mockNotifications: Notification[] = [
  {
    id: 'n1',
    title: 'Intervention planifiée',
    message: 'Maintenance climatisation planifiée pour le ' + format(addDays(new Date(), 3), 'dd/MM/yyyy'),
    type: 'info',
    read: false,
    createdAt: subDays(new Date(), 1),
    relatedTo: { type: 'intervention', id: 'i1' }
  },
  {
    id: 'n2',
    title: 'Intervention urgente',
    message: 'Panne critique sur la chaîne de production A',
    type: 'error',
    read: true,
    createdAt: subDays(new Date(), 2),
    relatedTo: { type: 'intervention', id: 'i5' }
  },
  {
    id: 'n3',
    title: 'Stock bas',
    message: 'Le stock de courroies de transmission A47 est sous le seuil minimum',
    type: 'warning',
    read: false,
    createdAt: subDays(new Date(), 3),
    relatedTo: { type: 'part', id: 'p4' }
  },
  {
    id: 'n4',
    title: 'Intervention terminée',
    message: 'La maintenance du système de sécurité a été complétée',
    type: 'success',
    read: false,
    createdAt: subDays(new Date(), 0.5),
    relatedTo: { type: 'intervention', id: 'i6' }
  }
];

// Mock KPIs
export const mockKPIs: KPI[] = [
  {
    title: 'Taux de disponibilité',
    value: 96.4,
    change: { value: 1.2, trend: 'up' },
    formatter: (value) => `${value}%`
  },
  {
    title: 'MTTR',
    value: 4.2,
    change: { value: 0.5, trend: 'down' },
    formatter: (value) => `${value}h`
  },
  {
    title: 'Interventions ouvertes',
    value: 12,
    change: { value: 3, trend: 'up' }
  },
  {
    title: 'Interventions en retard',
    value: 2,
    change: { value: 1, trend: 'down' }
  }
];

// Mock Chart Data
export const mockInterventionsByType = {
  labels: ['Préventif', 'Correctif', 'Réglementaire'],
  datasets: [{
    label: 'Nombre d\'interventions',
    data: [24, 18, 8],
    backgroundColor: ['#0062FF', '#FF6B00', '#00C853']
  }]
};

export const mockInterventionsByPriority = {
  labels: ['Critique', 'Haute', 'Moyenne', 'Basse'],
  datasets: [{
    label: 'Nombre d\'interventions',
    data: [3, 7, 28, 12],
    backgroundColor: ['#FF3D00', '#FF6B00', '#FFC107', '#0062FF']
  }]
};

export const mockMaintenanceCosts = {
  labels: ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Août', 'Sep', 'Oct', 'Nov', 'Déc'],
  datasets: [
    {
      label: 'Préventif',
      data: [4200, 3800, 5100, 4500, 5300, 6200, 5900, 6100, 5400, 5800, 4900, 4300],
      borderColor: '#0062FF',
      backgroundColor: 'rgba(0, 98, 255, 0.1)'
    },
    {
      label: 'Correctif',
      data: [1800, 2200, 1500, 3200, 2100, 1900, 2800, 2400, 3100, 2700, 3400, 2900],
      borderColor: '#FF6B00',
      backgroundColor: 'rgba(255, 107, 0, 0.1)'
    }
  ]
};