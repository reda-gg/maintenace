import React, { useState } from 'react';
import { BarChart2, Download, Calendar, Filter, ChevronDown } from 'lucide-react';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';
import { mockInterventionsByType, mockInterventionsByPriority, mockMaintenanceCosts } from '../utils/mockData';

const Reports: React.FC = () => {
  const [dateRange, setDateRange] = useState('month');
  const [reportType, setReportType] = useState('all');

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center space-y-4 md:space-y-0">
        <h1 className="text-2xl font-bold text-gray-900">Rapports et analyses</h1>
        
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            size="sm"
            icon={<Calendar size={16} />}
          >
            Planifier un rapport
          </Button>
          
          <Button 
            variant="primary" 
            size="sm"
            icon={<Download size={16} />}
          >
            Exporter les données
          </Button>
        </div>
      </div>
      
      {/* Filters */}
      <div className="bg-white p-4 rounded-lg border border-gray-200">
        <div className="flex flex-wrap gap-4">
          <div className="relative">
            <select
              className="appearance-none pl-9 pr-8 py-2 border border-gray-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
            >
              <option value="week">Cette semaine</option>
              <option value="month">Ce mois</option>
              <option value="quarter">Ce trimestre</option>
              <option value="year">Cette année</option>
            </select>
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Calendar size={16} className="text-gray-400" />
            </div>
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
              <ChevronDown size={16} className="text-gray-400" />
            </div>
          </div>
          
          <div className="relative">
            <select
              className="appearance-none pl-9 pr-8 py-2 border border-gray-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              value={reportType}
              onChange={(e) => setReportType(e.target.value)}
            >
              <option value="all">Tous les rapports</option>
              <option value="interventions">Interventions</option>
              <option value="costs">Coûts</option>
              <option value="performance">Performance</option>
            </select>
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Filter size={16} className="text-gray-400" />
            </div>
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
              <ChevronDown size={16} className="text-gray-400" />
            </div>
          </div>
        </div>
      </div>
      
      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Interventions by Type */}
        <Card title="Répartition des interventions par type">
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={mockInterventionsByType.datasets[0].data.map((value, index) => ({
                name: mockInterventionsByType.labels[index],
                value
              }))}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="value" fill="#0062FF" name="Nombre d'interventions" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
        
        {/* Interventions by Priority */}
        <Card title="Répartition des interventions par priorité">
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={mockInterventionsByPriority.datasets[0].data.map((value, index) => ({
                name: mockInterventionsByPriority.labels[index],
                value
              }))}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="value" fill="#FF6B00" name="Nombre d'interventions" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
        
        {/* Maintenance Costs */}
        <Card title="Coûts de maintenance" className="lg:col-span-2">
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={mockMaintenanceCosts.labels.map((month, index) => ({
                name: month,
                preventif: mockMaintenanceCosts.datasets[0].data[index],
                correctif: mockMaintenanceCosts.datasets[1].data[index]
              }))}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="preventif" 
                  stroke="#0062FF" 
                  name="Préventif"
                  strokeWidth={2}
                />
                <Line 
                  type="monotone" 
                  dataKey="correctif" 
                  stroke="#FF6B00" 
                  name="Correctif"
                  strokeWidth={2}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Reports;