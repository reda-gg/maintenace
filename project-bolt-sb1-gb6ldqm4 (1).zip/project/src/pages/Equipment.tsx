import React, { useState } from 'react';
import { HardDrive, Filter, Search, Plus, Download, ArrowUpDown, ChevronDown, Grid, List, MapPin, PenTool as Tool, Calendar } from 'lucide-react';
import Button from '../components/ui/Button';
import StatusIndicator from '../components/ui/StatusIndicator';
import Card from '../components/ui/Card';
import { mockEquipment } from '../utils/mockData';
import { format, getRelativeTimeString } from '../utils/dateUtils';

const Equipment: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  
  // Get unique categories
  const categories = Array.from(new Set(mockEquipment.map(item => item.category)));
  
  // Filter equipment based on search and filters
  const filteredEquipment = mockEquipment.filter(equipment => {
    // Search filter
    const matchesSearch = searchTerm === '' || 
      equipment.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      equipment.serialNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      equipment.location.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Status filter
    const matchesStatus = statusFilter === 'all' || equipment.status === statusFilter;
    
    // Category filter
    const matchesCategory = categoryFilter === 'all' || equipment.category === categoryFilter;
    
    return matchesSearch && matchesStatus && matchesCategory;
  });
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center space-y-4 md:space-y-0">
        <h1 className="text-2xl font-bold text-gray-900">Équipements</h1>
        
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            size="sm"
            icon={<Tool size={16} />}
          >
            Maintenance
          </Button>
          
          <Button 
            variant="primary" 
            size="sm"
            icon={<Plus size={16} />}
          >
            Nouvel équipement
          </Button>
        </div>
      </div>
      
      {/* Filters */}
      <div className="bg-white p-4 rounded-lg border border-gray-200 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center space-y-3 md:space-y-0 md:space-x-4">
          <div className="relative md:w-96">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={18} className="text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Rechercher des équipements..."
              className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex flex-wrap gap-2">
            <div className="relative">
              <select
                className="appearance-none pl-9 pr-8 py-2 border border-gray-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              >
                <option value="all">Tous les statuts</option>
                <option value="operational">Opérationnel</option>
                <option value="maintenance">En maintenance</option>
                <option value="breakdown">En panne</option>
                <option value="retired">Retiré</option>
              </select>
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <HardDrive size={16} className="text-gray-400" />
              </div>
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <ChevronDown size={16} className="text-gray-400" />
              </div>
            </div>
            
            <div className="relative">
              <select
                className="appearance-none pl-9 pr-8 py-2 border border-gray-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
              >
                <option value="all">Toutes les catégories</option>
                {categories.map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Filter size={16} className="text-gray-400" />
              </div>
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <ChevronDown size={16} className="text-gray-400" />
              </div>
            </div>
            
            <div className="flex items-center space-x-1 border border-gray-300 rounded-md bg-white">
              <button
                className={`p-2 ${viewMode === 'grid' ? 'bg-gray-100 text-gray-800' : 'text-gray-500'}`}
                onClick={() => setViewMode('grid')}
              >
                <Grid size={16} />
              </button>
              <button
                className={`p-2 ${viewMode === 'list' ? 'bg-gray-100 text-gray-800' : 'text-gray-500'}`}
                onClick={() => setViewMode('list')}
              >
                <List size={16} />
              </button>
            </div>
            
            <Button 
              variant="outline" 
              size="sm" 
              icon={<Download size={16} />}
            >
              Exporter
            </Button>
          </div>
        </div>
      </div>
      
      {/* Equipment List/Grid */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredEquipment.length === 0 ? (
            <div className="col-span-full p-12 text-center text-gray-500 bg-white rounded-lg border border-gray-200">
              <div className="flex flex-col items-center">
                <HardDrive size={36} className="text-gray-400 mb-2" />
                <p>Aucun équipement trouvé</p>
              </div>
            </div>
          ) : (
            filteredEquipment.map(equipment => (
              <Card key={equipment.id} className="transition-transform hover:scale-105">
                <div className="aspect-video rounded-md overflow-hidden mb-4">
                  <img 
                    src={equipment.image || "https://images.pexels.com/photos/257736/pexels-photo-257736.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"}
                    alt={equipment.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                
                <div className="flex items-start justify-between mb-3">
                  <h3 className="font-medium text-gray-900 truncate">{equipment.name}</h3>
                  <StatusIndicator status={equipment.status} />
                </div>
                
                <div className="space-y-2 text-sm text-gray-600">
                  <div className="flex items-center">
                    <MapPin size={14} className="mr-2 flex-shrink-0" />
                    <span className="truncate">{equipment.location}</span>
                  </div>
                  <div className="flex items-center">
                    <Calendar size={14} className="mr-2 flex-shrink-0" />
                    <span>
                      {equipment.nextMaintenance 
                        ? `Prochaine maintenance: ${getRelativeTimeString(equipment.nextMaintenance)}`
                        : 'Aucune maintenance planifiée'
                      }
                    </span>
                  </div>
                </div>
                
                <div className="mt-4 pt-4 border-t border-gray-100 flex justify-between">
                  <span className="text-xs text-gray-500">
                    {equipment.serialNumber}
                  </span>
                  <Button variant="outline" size="sm">
                    Détails
                  </Button>
                </div>
              </Card>
            ))
          )}
        </div>
      ) : (
        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    <div className="flex items-center space-x-1">
                      <span>Équipement</span>
                      <button className="text-gray-400 hover:text-gray-500">
                        <ArrowUpDown size={14} />
                      </button>
                    </div>
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    <div className="flex items-center space-x-1">
                      <span>Emplacement</span>
                      <button className="text-gray-400 hover:text-gray-500">
                        <ArrowUpDown size={14} />
                      </button>
                    </div>
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    <div className="flex items-center space-x-1">
                      <span>Statut</span>
                      <button className="text-gray-400 hover:text-gray-500">
                        <ArrowUpDown size={14} />
                      </button>
                    </div>
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    <div className="flex items-center space-x-1">
                      <span>Dernière maintenance</span>
                      <button className="text-gray-400 hover:text-gray-500">
                        <ArrowUpDown size={14} />
                      </button>
                    </div>
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    <div className="flex items-center space-x-1">
                      <span>Prochaine maintenance</span>
                      <button className="text-gray-400 hover:text-gray-500">
                        <ArrowUpDown size={14} />
                      </button>
                    </div>
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredEquipment.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center text-gray-500">
                      <div className="flex flex-col items-center">
                        <HardDrive size={36} className="text-gray-400 mb-2" />
                        <p>Aucun équipement trouvé</p>
                      </div>
                    </td>
                  </tr>
                ) : (
                  filteredEquipment.map(equipment => (
                    <tr key={equipment.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-10 w-10">
                            <img 
                              src={equipment.image || "https://images.pexels.com/photos/257736/pexels-photo-257736.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"}
                              alt={equipment.name}
                              className="h-10 w-10 rounded object-cover"
                            />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">{equipment.name}</div>
                            <div className="text-sm text-gray-500">{equipment.serialNumber}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{equipment.location}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <StatusIndicator status={equipment.status} />
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {equipment.lastMaintenance
                            ? format(new Date(equipment.lastMaintenance), 'dd/MM/yyyy')
                            : 'N/A'
                          }
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {equipment.nextMaintenance
                            ? format(new Date(equipment.nextMaintenance), 'dd/MM/yyyy')
                            : 'N/A'
                          }
                        </div>
                        {equipment.nextMaintenance && (
                          <div className="text-xs text-gray-500">
                            {getRelativeTimeString(equipment.nextMaintenance)}
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <Button 
                          variant="outline" 
                          size="sm"
                        >
                          Voir
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default Equipment;