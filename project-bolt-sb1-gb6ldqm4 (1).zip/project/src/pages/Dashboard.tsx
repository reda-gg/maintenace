import React from 'react';
import { 
  Activity, Wrench, Package, Timer, BarChart2, 
  Calendar, Users, ArrowRight
} from 'lucide-react';
import StatCard from '../components/ui/StatCard';
import InterventionsList from '../components/dashboard/InterventionsList';
import EquipmentStatus from '../components/dashboard/EquipmentStatus';
import InventoryStatus from '../components/dashboard/InventoryStatus';
import Button from '../components/ui/Button';
import { 
  mockInterventions, mockEquipment, mockUsers, 
  mockParts, mockKPIs
} from '../utils/mockData';

const Dashboard: React.FC = () => {
  // Filter only upcoming interventions (planned or in-progress)
  const upcomingInterventions = mockInterventions
    .filter(int => ['planned', 'in_progress'].includes(int.status))
    .sort((a, b) => {
      if (!a.scheduledFor) return 1;
      if (!b.scheduledFor) return -1;
      return new Date(a.scheduledFor).getTime() - new Date(b.scheduledFor).getTime();
    })
    .slice(0, 5);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Tableau de bord</h1>
        
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            size="sm"
            icon={<Calendar size={16} />}
          >
            Planning
          </Button>
          
          <Button 
            variant="primary" 
            size="sm"
            icon={<Wrench size={16} />}
          >
            Nouvelle intervention
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          title="Taux de disponibilité" 
          value="96.4%" 
          icon={<Activity size={20} />}
          change={{ value: 1.2, trend: 'up' }}
        />
        <StatCard 
          title="MTTR" 
          value="4.2h" 
          icon={<Timer size={20} />}
          change={{ value: 0.5, trend: 'down' }}
        />
        <StatCard 
          title="Interventions ouvertes" 
          value="12" 
          icon={<Wrench size={20} />}
          change={{ value: 3, trend: 'up' }}
        />
        <StatCard 
          title="Interventions en retard" 
          value="2" 
          icon={<BarChart2 size={20} />}
          change={{ value: 1, trend: 'down' }}
        />
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (interventions list) */}
        <div className="lg:col-span-6">
          <InterventionsList 
            interventions={upcomingInterventions} 
            equipment={mockEquipment}
            users={mockUsers}
          />
          
          <div className="mt-4 flex justify-center">
            <Button 
              variant="outline"
              icon={<ArrowRight size={16} />}
              iconPosition="right"
            >
              Voir toutes les interventions
            </Button>
          </div>
        </div>
        
        {/* Right Column (equipment and inventory) */}
        <div className="lg:col-span-6 space-y-6">
          <EquipmentStatus equipment={mockEquipment} />
          <InventoryStatus parts={mockParts} />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;