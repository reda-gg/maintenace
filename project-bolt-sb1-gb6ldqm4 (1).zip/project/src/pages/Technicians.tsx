import React, { useState } from 'react';
import { Users, Search, Plus, Download, ArrowUpDown, ChevronDown, Mail, Phone } from 'lucide-react';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import Badge from '../components/ui/Badge';
import { mockUsers } from '../utils/mockData';

const Technicians: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  
  const filteredTechnicians = mockUsers.filter(user => {
    const matchesSearch = searchTerm === '' || 
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesRole = roleFilter === 'all' || user.role === roleFilter;
    
    return matchesSearch && matchesRole;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center space-y-4 md:space-y-0">
        <h1 className="text-2xl font-bold text-gray-900">Techniciens et prestataires</h1>
        
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            size="sm"
            icon={<Mail size={16} />}
          >
            Envoyer un message
          </Button>
          
          <Button 
            variant="primary" 
            size="sm"
            icon={<Plus size={16} />}
          >
            Ajouter un technicien
          </Button>
        </div>
      </div>
      
      {/* Filters */}
      <div className="bg-white p-4 rounded-lg border border-gray-200 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center space-y-3 md:space-y-0 md:space-x-4">
          <div className="relative md:w-96">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={18} className="text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Rechercher des techniciens..."
              className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex flex-wrap gap-2">
            <div className="relative">
              <select
                className="appearance-none pl-9 pr-8 py-2 border border-gray-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                value={roleFilter}
                onChange={(e) => setRoleFilter(e.target.value)}
              >
                <option value="all">Tous les rôles</option>
                <option value="technician">Techniciens</option>
                <option value="manager">Managers</option>
                <option value="admin">Administrateurs</option>
              </select>
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Users size={16} className="text-gray-400" />
              </div>
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <ChevronDown size={16} className="text-gray-400" />
              </div>
            </div>
            
            <Button 
              variant="outline" 
              size="sm" 
              icon={<Download size={16} />}
            >
              Exporter
            </Button>
          </div>
        </div>
      </div>
      
      {/* Technicians Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredTechnicians.length === 0 ? (
          <div className="col-span-full p-12 text-center text-gray-500 bg-white rounded-lg border border-gray-200">
            <div className="flex flex-col items-center">
              <Users size={36} className="text-gray-400 mb-2" />
              <p>Aucun technicien trouvé</p>
            </div>
          </div>
        ) : (
          filteredTechnicians.map(technician => (
            <Card key={technician.id}>
              <div className="flex items-center space-x-4">
                <img 
                  src={technician.avatar} 
                  alt={technician.name}
                  className="w-16 h-16 rounded-full object-cover"
                />
                <div>
                  <h3 className="font-medium text-gray-900">{technician.name}</h3>
                  <Badge variant={
                    technician.role === 'admin' ? 'error' :
                    technician.role === 'manager' ? 'warning' :
                    'info'
                  }>
                    {technician.role === 'admin' ? 'Administrateur' :
                     technician.role === 'manager' ? 'Manager' :
                     technician.role === 'technician' ? 'Technicien' :
                     'Demandeur'
                    }
                  </Badge>
                </div>
              </div>
              
              <div className="mt-4 space-y-2 text-sm text-gray-600">
                <div className="flex items-center">
                  <Mail size={14} className="mr-2 flex-shrink-0" />
                  <a href={`mailto:${technician.email}`} className="hover:text-blue-600">
                    {technician.email}
                  </a>
                </div>
                <div className="flex items-center">
                  <Phone size={14} className="mr-2 flex-shrink-0" />
                  <span>+33 6 12 34 56 78</span>
                </div>
              </div>
              
              <div className="mt-4 pt-4 border-t border-gray-100 flex justify-between items-center">
                <Button variant="outline" size="sm">
                  Voir le profil
                </Button>
                <Button variant="outline" size="sm" icon={<Mail size={14} />}>
                  Contact
                </Button>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};

export default Technicians;