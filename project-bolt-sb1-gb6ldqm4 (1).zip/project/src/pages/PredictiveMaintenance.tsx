import React, { useState } from 'react';
import { Activity, AlertTriangle, BarChart2, Download, Filter, ChevronDown, Settings, Gauge } from 'lucide-react';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import Badge from '../components/ui/Badge';
import { mockEquipment } from '../utils/mockData';

// Mock sensor data
const mockSensorData = {
  temperature: Array.from({ length: 24 }, (_, i) => ({
    time: `${i}:00`,
    value: 45 + Math.random() * 10,
    threshold: 50
  })),
  vibration: Array.from({ length: 24 }, (_, i) => ({
    time: `${i}:00`,
    value: 2 + Math.random() * 1.5,
    threshold: 3
  })),
  pressure: Array.from({ length: 24 }, (_, i) => ({
    time: `${i}:00`,
    value: 95 + Math.random() * 10,
    threshold: 100
  }))
};

// Mock predictions
const mockPredictions = [
  {
    id: 'p1',
    equipmentId: 'e1',
    parameter: 'temperature',
    probability: 85,
    estimatedTime: '48h',
    severity: 'high'
  },
  {
    id: 'p2',
    equipmentId: 'e3',
    parameter: 'vibration',
    probability: 65,
    estimatedTime: '96h',
    severity: 'medium'
  }
];

const PredictiveMaintenance: React.FC = () => {
  const [selectedEquipment, setSelectedEquipment] = useState('all');
  const [timeRange, setTimeRange] = useState('24h');

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center space-y-4 md:space-y-0">
        <h1 className="text-2xl font-bold text-gray-900">Maintenance prédictive</h1>
        
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            size="sm"
            icon={<Settings size={16} />}
          >
            Configuration
          </Button>
          
          <Button 
            variant="primary" 
            size="sm"
            icon={<Download size={16} />}
          >
            Exporter les données
          </Button>
        </div>
      </div>
      
      {/* Filters */}
      <div className="bg-white p-4 rounded-lg border border-gray-200">
        <div className="flex flex-wrap gap-4">
          <div className="relative">
            <select
              className="appearance-none pl-9 pr-8 py-2 border border-gray-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              value={selectedEquipment}
              onChange={(e) => setSelectedEquipment(e.target.value)}
            >
              <option value="all">Tous les équipements</option>
              {mockEquipment.map(equipment => (
                <option key={equipment.id} value={equipment.id}>
                  {equipment.name}
                </option>
              ))}
            </select>
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Filter size={16} className="text-gray-400" />
            </div>
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
              <ChevronDown size={16} className="text-gray-400" />
            </div>
          </div>
          
          <div className="relative">
            <select
              className="appearance-none pl-9 pr-8 py-2 border border-gray-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value)}
            >
              <option value="24h">Dernières 24h</option>
              <option value="7d">7 derniers jours</option>
              <option value="30d">30 derniers jours</option>
            </select>
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Activity size={16} className="text-gray-400" />
            </div>
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
              <ChevronDown size={16} className="text-gray-400" />
            </div>
          </div>
        </div>
      </div>
      
      {/* Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {mockPredictions.map(prediction => {
          const equipment = mockEquipment.find(e => e.id === prediction.equipmentId);
          return (
            <Card key={prediction.id} className="border-l-4 border-l-amber-500">
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-3">
                  <div className="p-2 bg-amber-100 rounded-lg">
                    <AlertTriangle size={24} className="text-amber-600" />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">{equipment?.name}</h3>
                    <p className="text-sm text-gray-500">
                      Risque de défaillance détecté - {prediction.parameter}
                    </p>
                  </div>
                </div>
                <Badge variant={
                  prediction.severity === 'high' ? 'error' :
                  prediction.severity === 'medium' ? 'warning' : 'info'
                }>
                  {prediction.probability}% de probabilité
                </Badge>
              </div>
              
              <div className="mt-4 flex items-center justify-between">
                <div className="text-sm text-gray-500">
                  Temps estimé avant défaillance: <span className="font-medium">{prediction.estimatedTime}</span>
                </div>
                <Button variant="outline" size="sm">
                  Voir les détails
                </Button>
              </div>
            </Card>
          );
        })}
      </div>
      
      {/* Sensor Data Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Temperature Chart */}
        <Card title="Température">
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={mockSensorData.temperature}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#FF6B00" 
                  name="Température (°C)"
                  strokeWidth={2}
                />
                <Line 
                  type="monotone" 
                  dataKey="threshold" 
                  stroke="#FF0000" 
                  strokeDasharray="5 5"
                  name="Seuil critique"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
        
        {/* Vibration Chart */}
        <Card title="Vibrations">
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={mockSensorData.vibration}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Area
                  type="monotone"
                  dataKey="value"
                  stroke="#0062FF"
                  fill="#0062FF"
                  fillOpacity={0.1}
                  name="Vibration (mm/s)"
                />
                <Line 
                  type="monotone" 
                  dataKey="threshold" 
                  stroke="#FF0000" 
                  strokeDasharray="5 5"
                  name="Seuil critique"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>
        
        {/* Pressure Chart */}
        <Card title="Pression" className="lg:col-span-2">
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={mockSensorData.pressure}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#00C853" 
                  name="Pression (bar)"
                  strokeWidth={2}
                />
                <Line 
                  type="monotone" 
                  dataKey="threshold" 
                  stroke="#FF0000" 
                  strokeDasharray="5 5"
                  name="Seuil critique"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default PredictiveMaintenance;