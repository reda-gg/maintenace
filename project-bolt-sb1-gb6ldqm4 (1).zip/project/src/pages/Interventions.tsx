import React, { useState } from 'react';
import { 
  Wrench, Filter, ChevronDown, Calendar, Clock, 
  Search, Plus, Download, ArrowUpDown
} from 'lucide-react';
import Button from '../components/ui/Button';
import StatusIndicator from '../components/ui/StatusIndicator';
import Badge from '../components/ui/Badge';
import { mockInterventions, mockEquipment, mockUsers } from '../utils/mockData';
import { format } from '../utils/dateUtils';

const Interventions: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  
  // Filter interventions based on search and filters
  const filteredInterventions = mockInterventions.filter(intervention => {
    // Search filter
    const matchesSearch = searchTerm === '' || 
      intervention.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      intervention.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Status filter
    const matchesStatus = statusFilter === 'all' || intervention.status === statusFilter;
    
    // Priority filter
    const matchesPriority = priorityFilter === 'all' || intervention.priority === priorityFilter;
    
    return matchesSearch && matchesStatus && matchesPriority;
  });
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center space-y-4 md:space-y-0">
        <h1 className="text-2xl font-bold text-gray-900">Interventions</h1>
        
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            size="sm"
            icon={<Calendar size={16} />}
          >
            Planning
          </Button>
          
          <Button 
            variant="primary" 
            size="sm"
            icon={<Plus size={16} />}
          >
            Nouvelle intervention
          </Button>
        </div>
      </div>
      
      {/* Filters */}
      <div className="bg-white p-4 rounded-lg border border-gray-200 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center space-y-3 md:space-y-0 md:space-x-4">
          <div className="relative md:w-96">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={18} className="text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Rechercher des interventions..."
              className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex flex-wrap gap-2">
            <div className="relative">
              <select
                className="appearance-none pl-9 pr-8 py-2 border border-gray-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              >
                <option value="all">Tous les statuts</option>
                <option value="requested">Demandée</option>
                <option value="planned">Planifiée</option>
                <option value="in_progress">En cours</option>
                <option value="on_hold">En attente</option>
                <option value="completed">Terminée</option>
                <option value="cancelled">Annulée</option>
              </select>
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Clock size={16} className="text-gray-400" />
              </div>
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <ChevronDown size={16} className="text-gray-400" />
              </div>
            </div>
            
            <div className="relative">
              <select
                className="appearance-none pl-9 pr-8 py-2 border border-gray-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                value={priorityFilter}
                onChange={(e) => setPriorityFilter(e.target.value)}
              >
                <option value="all">Toutes les priorités</option>
                <option value="low">Faible</option>
                <option value="medium">Moyenne</option>
                <option value="high">Haute</option>
                <option value="critical">Critique</option>
              </select>
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Filter size={16} className="text-gray-400" />
              </div>
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <ChevronDown size={16} className="text-gray-400" />
              </div>
            </div>
            
            <Button 
              variant="outline" 
              size="sm" 
              icon={<Download size={16} />}
            >
              Exporter
            </Button>
          </div>
        </div>
      </div>
      
      {/* Interventions Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <div className="flex items-center space-x-1">
                    <span>Intervention</span>
                    <button className="text-gray-400 hover:text-gray-500">
                      <ArrowUpDown size={14} />
                    </button>
                  </div>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <div className="flex items-center space-x-1">
                    <span>Équipement</span>
                    <button className="text-gray-400 hover:text-gray-500">
                      <ArrowUpDown size={14} />
                    </button>
                  </div>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <div className="flex items-center space-x-1">
                    <span>Statut</span>
                    <button className="text-gray-400 hover:text-gray-500">
                      <ArrowUpDown size={14} />
                    </button>
                  </div>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <div className="flex items-center space-x-1">
                    <span>Priorité</span>
                    <button className="text-gray-400 hover:text-gray-500">
                      <ArrowUpDown size={14} />
                    </button>
                  </div>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <div className="flex items-center space-x-1">
                    <span>Date</span>
                    <button className="text-gray-400 hover:text-gray-500">
                      <ArrowUpDown size={14} />
                    </button>
                  </div>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <div className="flex items-center space-x-1">
                    <span>Technicien</span>
                    <button className="text-gray-400 hover:text-gray-500">
                      <ArrowUpDown size={14} />
                    </button>
                  </div>
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredInterventions.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-gray-500">
                    <div className="flex flex-col items-center">
                      <Wrench size={36} className="text-gray-400 mb-2" />
                      <p>Aucune intervention trouvée</p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredInterventions.map(intervention => {
                  const relatedEquipment = mockEquipment.find(e => e.id === intervention.equipmentId);
                  const assignee = intervention.assigneeId 
                    ? mockUsers.find(u => u.id === intervention.assigneeId)
                    : null;
                  
                  return (
                    <tr key={intervention.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">{intervention.title}</div>
                        <div className="text-sm text-gray-500 truncate max-w-xs">{intervention.description}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{relatedEquipment?.name}</div>
                        <div className="text-xs text-gray-500">{relatedEquipment?.location}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <StatusIndicator status={intervention.status} />
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Badge variant={intervention.priority}>{
                          intervention.priority === 'low' ? 'Faible' :
                          intervention.priority === 'medium' ? 'Moyenne' :
                          intervention.priority === 'high' ? 'Haute' : 'Critique'
                        }</Badge>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {intervention.scheduledFor 
                            ? format(new Date(intervention.scheduledFor), 'dd/MM/yyyy')
                            : 'Non planifiée'
                          }
                        </div>
                        {intervention.estimatedDuration && (
                          <div className="text-xs text-gray-500">
                            {Math.floor(intervention.estimatedDuration / 60)}h{intervention.estimatedDuration % 60 > 0 ? `${intervention.estimatedDuration % 60}m` : ''}
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {assignee ? (
                          <div className="flex items-center">
                            <img 
                              src={assignee.avatar} 
                              alt={assignee.name}
                              className="w-6 h-6 rounded-full mr-2"
                            />
                            <div className="text-sm text-gray-900">{assignee.name}</div>
                          </div>
                        ) : (
                          <div className="text-sm text-gray-500">Non assignée</div>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <Button 
                          variant="outline" 
                          size="sm"
                        >
                          Voir
                        </Button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Interventions;