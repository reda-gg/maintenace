import { createBrowserRouter } from 'react-router-dom';
import Layout from './components/layout/Layout';
import Dashboard from './pages/Dashboard';
import Interventions from './pages/Interventions';
import Equipment from './pages/Equipment';
import Technicians from './pages/Technicians';
import Reports from './pages/Reports';
import PredictiveMaintenance from './pages/PredictiveMaintenance';
import NotFound from './pages/NotFound';

const router = createBrowserRouter([
  {
    path: '/',
    element: <Layout />,
    children: [
      {
        index: true,
        element: <Dashboard />
      },
      {
        path: 'interventions',
        element: <Interventions />
      },
      {
        path: 'equipments',
        element: <Equipment />
      },
      {
        path: 'technicians',
        element: <Technicians />
      },
      {
        path: 'reports',
        element: <Reports />
      },
      {
        path: 'predictive',
        element: <PredictiveMaintenance />
      },
      {
        path: '*',
        element: <NotFound />
      }
    ]
  }
]);

export default router;