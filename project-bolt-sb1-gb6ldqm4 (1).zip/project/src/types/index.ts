// Core entity types
export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'manager' | 'technician' | 'requester';
  avatar?: string;
}

export interface Equipment {
  id: string;
  name: string;
  category: string;
  location: string;
  serialNumber: string;
  installDate: string;
  lastMaintenance?: string;
  nextMaintenance?: string;
  status: 'operational' | 'maintenance' | 'breakdown' | 'retired';
  manufacturer: string;
  model: string;
  notes?: string;
  documents?: Document[];
  image?: string;
}

export interface Intervention {
  id: string;
  title: string;
  description: string;
  equipmentId: string;
  requesterId: string;
  assigneeId?: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  status: 'requested' | 'planned' | 'in_progress' | 'on_hold' | 'completed' | 'cancelled';
  type: 'preventive' | 'corrective' | 'regulatory';
  createdAt: string;
  scheduledFor?: string;
  completedAt?: string;
  estimatedDuration?: number; // in minutes
  actualDuration?: number; // in minutes
  partsUsed?: Part[];
  notes?: string;
  documents?: Document[];
}

export interface Part {
  id: string;
  name: string;
  reference: string;
  location: string;
  quantity: number;
  minimumStock: number;
  unitPrice: number;
  supplier: string;
  category: string;
  lastRestockDate?: string;
  image?: string;
}

export interface Document {
  id: string;
  name: string;
  type: string;
  url: string;
  createdAt: string;
  createdBy: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'success' | 'error';
  read: boolean;
  createdAt: string;
  relatedTo?: {
    type: 'intervention' | 'equipment' | 'part';
    id: string;
  };
}

// Dashboard types
export interface KPI {
  title: string;
  value: number | string;
  change?: {
    value: number;
    trend: 'up' | 'down' | 'neutral';
  };
  formatter?: (value: number | string) => string;
}

export interface ChartData {
  labels: string[];
  datasets: {
    label: string;
    data: number[];
    backgroundColor?: string | string[];
    borderColor?: string | string[];
  }[];
}